--
-- PostgreSQL database dump
--

\restrict 2kTlexZJM7U3KEwrDy3BH1XCCvh9xsxhdJj9GcPOoE5gS2ZYPraH0pTwrUSTPF1

-- Dumped from database version 18.3
-- Dumped by pg_dump version 18.3

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: accounts; Type: TABLE; Schema: public; Owner: llmexcel
--

CREATE TABLE public.accounts (
    id uuid NOT NULL,
    account_id character varying(255) NOT NULL,
    provider_id character varying(50) NOT NULL,
    user_id uuid NOT NULL,
    access_token text,
    refresh_token text,
    id_token text,
    access_token_expires_at timestamp with time zone,
    refresh_token_expires_at timestamp with time zone,
    scope character varying(255),
    password character varying(255),
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


ALTER TABLE public.accounts OWNER TO llmexcel;

--
-- Name: alembic_version; Type: TABLE; Schema: public; Owner: llmexcel
--

CREATE TABLE public.alembic_version (
    version_num character varying(32) NOT NULL
);


ALTER TABLE public.alembic_version OWNER TO llmexcel;

--
-- Name: btracks; Type: TABLE; Schema: public; Owner: llmexcel
--

CREATE TABLE public.btracks (
    id uuid NOT NULL,
    reporter_id uuid NOT NULL,
    created_at timestamp with time zone NOT NULL,
    steps jsonb NOT NULL,
    generation_prompt text NOT NULL,
    errors text NOT NULL,
    thread_turn_id uuid NOT NULL,
    cause text,
    fixed boolean NOT NULL
);


ALTER TABLE public.btracks OWNER TO llmexcel;

--
-- Name: files; Type: TABLE; Schema: public; Owner: llmexcel
--

CREATE TABLE public.files (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    filename character varying(255) NOT NULL,
    file_path character varying(512) NOT NULL,
    file_size integer NOT NULL,
    md5 character varying(32) NOT NULL,
    mime_type character varying(100),
    uploaded_at timestamp with time zone NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


ALTER TABLE public.files OWNER TO llmexcel;

--
-- Name: permissions; Type: TABLE; Schema: public; Owner: llmexcel
--

CREATE TABLE public.permissions (
    id uuid NOT NULL,
    name character varying(100) NOT NULL,
    code character varying(100) NOT NULL,
    description character varying(500),
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


ALTER TABLE public.permissions OWNER TO llmexcel;

--
-- Name: refresh_tokens; Type: TABLE; Schema: public; Owner: llmexcel
--

CREATE TABLE public.refresh_tokens (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    token character varying(512) NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    is_revoked boolean NOT NULL,
    device_info character varying(255),
    user_agent text,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


ALTER TABLE public.refresh_tokens OWNER TO llmexcel;

--
-- Name: role_permissions; Type: TABLE; Schema: public; Owner: llmexcel
--

CREATE TABLE public.role_permissions (
    id uuid NOT NULL,
    role_id uuid NOT NULL,
    permission_id uuid NOT NULL,
    created_at timestamp with time zone NOT NULL
);


ALTER TABLE public.role_permissions OWNER TO llmexcel;

--
-- Name: roles; Type: TABLE; Schema: public; Owner: llmexcel
--

CREATE TABLE public.roles (
    id uuid NOT NULL,
    name character varying(100) NOT NULL,
    code character varying(50) NOT NULL,
    description character varying(500),
    is_system boolean NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


ALTER TABLE public.roles OWNER TO llmexcel;

--
-- Name: thread_turns; Type: TABLE; Schema: public; Owner: llmexcel
--

CREATE TABLE public.thread_turns (
    id uuid NOT NULL,
    thread_id uuid NOT NULL,
    turn_number integer NOT NULL,
    user_query text NOT NULL,
    status character varying(20) NOT NULL,
    steps jsonb NOT NULL,
    created_at timestamp with time zone NOT NULL,
    started_at timestamp with time zone,
    completed_at timestamp with time zone,
    updated_at timestamp with time zone NOT NULL
);


ALTER TABLE public.thread_turns OWNER TO llmexcel;

--
-- Name: threads; Type: TABLE; Schema: public; Owner: llmexcel
--

CREATE TABLE public.threads (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    title character varying(255),
    status character varying(20) NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


ALTER TABLE public.threads OWNER TO llmexcel;

--
-- Name: turn_files; Type: TABLE; Schema: public; Owner: llmexcel
--

CREATE TABLE public.turn_files (
    id uuid NOT NULL,
    turn_id uuid NOT NULL,
    file_id uuid NOT NULL,
    created_at timestamp with time zone NOT NULL
);


ALTER TABLE public.turn_files OWNER TO llmexcel;

--
-- Name: user_roles; Type: TABLE; Schema: public; Owner: llmexcel
--

CREATE TABLE public.user_roles (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    role_id uuid NOT NULL,
    created_at timestamp with time zone NOT NULL
);


ALTER TABLE public.user_roles OWNER TO llmexcel;

--
-- Name: users; Type: TABLE; Schema: public; Owner: llmexcel
--

CREATE TABLE public.users (
    id uuid NOT NULL,
    username character varying(255) NOT NULL,
    avatar character varying(512) NOT NULL,
    status smallint NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    last_login_at timestamp with time zone
);


ALTER TABLE public.users OWNER TO llmexcel;

--
-- Data for Name: accounts; Type: TABLE DATA; Schema: public; Owner: llmexcel
--

COPY public.accounts (id, account_id, provider_id, user_id, access_token, refresh_token, id_token, access_token_expires_at, refresh_token_expires_at, scope, password, created_at, updated_at) FROM stdin;
ca2d54ed-015e-44a7-a726-4a8ca8a04c6a	918494283@qq.com	credentials	0d7f1aa2-b898-4f2a-a10a-54ac712fbde6	\N	\N	\N	\N	\N	\N	$2b$12$7aftNw6Rlhny5GJ/8lLeEOuFjEwO/pr.m5R215uLXVpVrykU0RD2O	2026-03-03 12:40:53.976591+00	2026-03-03 12:40:53.976595+00
bcae4bc0-28be-48ff-86b8-c1cec96e6529	admin@selgetable.com	credentials	d7fe11df-0914-440f-a7fd-ff61aa05ab9d	\N	\N	\N	\N	\N	\N	\\\\\\/9qL9pjNHofbQA/dG	2026-02-07 04:15:21.001994+00	2026-02-07 04:15:21.002+00
0335a33b-8ee5-48ae-8026-056bc42ba534	jaydenliao1027@gmail.com	credentials	43cb8f36-2330-49e8-bdab-febc0338268e	\N	\N	\N	\N	\N	\N	$2b$12$cat.pVyfVnd82fuCUuQHUOdzY5c/9YSlki5pkE0pqMhEu6x7MsjXW	2026-03-03 12:53:00.31469+00	2026-03-03 12:53:00.314694+00
42f7d1a0-9371-473d-8e56-e3db7b158a98	18@qq.com	credentials	2525de1f-db07-4700-a56d-b2976b6ac8e4	\N	\N	\N	\N	\N	\N	$2b$12$Mxt8CsLJwVBGFXB.S6B6d.doiKQEPijF9zTGcaewFZeZPQyM22DYq	2026-03-03 12:53:37.812078+00	2026-03-03 12:53:37.812082+00
\.


--
-- Data for Name: alembic_version; Type: TABLE DATA; Schema: public; Owner: llmexcel
--

COPY public.alembic_version (version_num) FROM stdin;
648d4ca39b77
\.


--
-- Data for Name: btracks; Type: TABLE DATA; Schema: public; Owner: llmexcel
--

COPY public.btracks (id, reporter_id, created_at, steps, generation_prompt, errors, thread_turn_id, cause, fixed) FROM stdin;
\.


--
-- Data for Name: files; Type: TABLE DATA; Schema: public; Owner: llmexcel
--

COPY public.files (id, user_id, filename, file_path, file_size, md5, mime_type, uploaded_at, created_at, updated_at) FROM stdin;
7011c47e-2266-482f-b146-c2c8faeb1e1a	0d7f1aa2-b898-4f2a-a10a-54ac712fbde6	1_titanic.xlsx	/storage/llm-excel/uploads/0d7f1aa2-b898-4f2a-a10a-54ac712fbde6/7011c47e2266482fb146c2c8faeb1e1a.xlsx	75570		application/vnd.openxmlformats-officedocument.spreadsheetml.sheet	2026-03-03 12:41:04.513312+00	2026-03-03 12:41:04.513318+00	2026-03-03 12:41:04.513319+00
\.


--
-- Data for Name: permissions; Type: TABLE DATA; Schema: public; Owner: llmexcel
--

COPY public.permissions (id, name, code, description, created_at, updated_at) FROM stdin;
3840ce3a-6d84-4be2-a6c5-ba1ecf074d93	All	*:*	所有权限（超级管理员）	2026-02-06 18:20:44.198122+00	2026-02-06 18:20:44.198127+00
eb4a52d4-c4bd-4ca7-9519-d219f0d242c9	Btrack Export	btrack:export	导出所有异常记录为 JSON	2026-02-06 18:20:44.209469+00	2026-02-06 18:20:44.209476+00
6f4c185f-f02f-4fc6-bea9-2696cf81d32c	Btrack Read	btrack:read	查看自己的异常记录	2026-02-06 18:20:44.211908+00	2026-02-06 18:20:44.211912+00
3dc6d70a-00f0-424c-a6f2-59679d9311fd	Btrack Read All	btrack:read:all	查看所有用户的异常记录	2026-02-06 18:20:44.213659+00	2026-02-06 18:20:44.213663+00
6ce4b23c-3aa7-4b04-86a6-12b26654887f	Btrack Update	btrack:update	更新异常状态（标记已修复）	2026-02-06 18:20:44.216049+00	2026-02-06 18:20:44.216053+00
11bb4613-0754-43f9-b70c-74915b88a3f9	Excel Download	excel:download	下载处理后的文件	2026-02-06 18:20:44.217911+00	2026-02-06 18:20:44.217914+00
88a6cb6a-f2aa-42ac-b4a8-60f0042bbd48	Excel Preview	excel:preview	预览处理结果	2026-02-06 18:20:44.220106+00	2026-02-06 18:20:44.22011+00
ace2e589-2744-4451-ac7e-7582e4c367bd	Excel Process	excel:process	使用 Excel 处理功能	2026-02-06 18:20:44.22185+00	2026-02-06 18:20:44.221853+00
9017e12a-1691-468c-b721-330bbc911949	File Delete	file:delete	删除自己的文件	2026-02-06 18:20:44.223347+00	2026-02-06 18:20:44.223349+00
c5a89bbd-78bb-43ef-836f-e5d4ba761328	File Download	file:download	下载文件（包含处理结果）	2026-02-06 18:20:44.224819+00	2026-02-06 18:20:44.224821+00
261721b6-025e-491f-8f2e-94db155d5979	File Read	file:read	查看自己上传的文件	2026-02-06 18:20:44.226463+00	2026-02-06 18:20:44.226465+00
10eb8e34-e6de-4e51-8708-d9e3092b1c33	File Read All	file:read:all	查看所有用户的文件	2026-02-06 18:20:44.229689+00	2026-02-06 18:20:44.229692+00
83613907-85cf-46d6-905c-2b6bd023634e	File Upload	file:upload	上传 Excel 文件	2026-02-06 18:20:44.231376+00	2026-02-06 18:20:44.231379+00
33b87eef-1d9f-4dee-bc55-cb01ee5ed581	Permission Manage	permission:manage	管理权限（创建、编辑、删除）	2026-02-06 18:20:44.233346+00	2026-02-06 18:20:44.233352+00
11fb17f1-dcef-46de-819a-e4405720eb83	Permission Read	permission:read	查看权限列表和详情	2026-02-06 18:20:44.236067+00	2026-02-06 18:20:44.236072+00
edc4840c-4b8f-4b67-8053-d9f4c32b84b2	Role Assign Permission	role:assign_permission	为角色分配权限	2026-02-06 18:20:44.238193+00	2026-02-06 18:20:44.238197+00
185db440-2875-43f7-bb8d-b967f6273fda	Role Create	role:create	创建自定义角色	2026-02-06 18:20:44.240067+00	2026-02-06 18:20:44.240071+00
7f014341-a8d7-44a2-88c0-bac5d12d8ed5	Role Delete	role:delete	删除自定义角色（系统角色不可删除）	2026-02-06 18:20:44.242092+00	2026-02-06 18:20:44.242096+00
35b022af-4d92-436e-bc74-9f715baad222	Role Read	role:read	查看角色列表和详情	2026-02-06 18:20:44.243837+00	2026-02-06 18:20:44.243842+00
4b62107a-052d-4082-9671-d93812ee6408	Role Update	role:update	编辑角色信息	2026-02-06 18:20:44.246591+00	2026-02-06 18:20:44.246596+00
e704d8e7-d322-4976-8937-d501c5744fbc	System All	system:*	所有系统管理权限	2026-02-06 18:20:44.24866+00	2026-02-06 18:20:44.248665+00
84a4a2d5-abf4-439e-8844-042f463b752e	System Logs	system:logs	查看系统日志	2026-02-06 18:20:44.250878+00	2026-02-06 18:20:44.250884+00
67db43f1-30cd-46c2-9e89-9180514fcadf	System Settings	system:settings	修改系统配置	2026-02-06 18:20:44.25355+00	2026-02-06 18:20:44.253555+00
a6c0508e-354b-488c-87ad-4bb3ea5fe300	Thread Delete	thread:delete	删除自己的会话	2026-02-06 18:20:44.2558+00	2026-02-06 18:20:44.255805+00
c2d2b161-e65b-4613-b213-553c8d530354	Thread Delete All	thread:delete:all	删除任意用户的会话	2026-02-06 18:20:44.258019+00	2026-02-06 18:20:44.258024+00
7a1c6e40-100d-452c-b050-43130ee10a5f	Thread Read	thread:read	查看自己的会话	2026-02-06 18:20:44.260054+00	2026-02-06 18:20:44.260058+00
1390160c-820b-4166-824b-9e68de14ff99	Thread Read All	thread:read:all	查看所有用户的会话	2026-02-06 18:20:44.26257+00	2026-02-06 18:20:44.262574+00
2beb5acc-9811-4cc5-bfe3-878f372a92c5	Thread Update	thread:update	编辑自己的会话	2026-02-06 18:20:44.264589+00	2026-02-06 18:20:44.264593+00
aee1f86d-9b2b-43e4-bb35-570f110a9c9c	Thread Write	thread:write	创建新会话	2026-02-06 18:20:44.266613+00	2026-02-06 18:20:44.266616+00
32f73a0f-4492-4752-a250-636cb56ed22f	User Assign Role	user:assign_role	为用户分配角色	2026-02-06 18:20:44.268197+00	2026-02-06 18:20:44.2682+00
c8074294-02cc-4503-b774-5225885f875b	User Create	user:create	创建新用户	2026-02-06 18:20:44.27006+00	2026-02-06 18:20:44.270063+00
a8208b93-015d-4603-8d2e-4d64e19ff29a	User Delete	user:delete	删除用户	2026-02-06 18:20:44.272034+00	2026-02-06 18:20:44.272037+00
192a2cf7-3620-47ff-951f-254c19554037	User Read	user:read	查看用户列表和详情	2026-02-06 18:20:44.275925+00	2026-02-06 18:20:44.27593+00
e26951bc-aa09-4ff5-824d-b99879460663	User Update	user:update	编辑用户信息	2026-02-06 18:20:44.279512+00	2026-02-06 18:20:44.279518+00
\.


--
-- Data for Name: refresh_tokens; Type: TABLE DATA; Schema: public; Owner: llmexcel
--

COPY public.refresh_tokens (id, user_id, token, expires_at, is_revoked, device_info, user_agent, created_at, updated_at) FROM stdin;
1a14817e-62dc-4c26-bc08-cb672ba65383	0d7f1aa2-b898-4f2a-a10a-54ac712fbde6	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIwZDdmMWFhMi1iODk4LTRmMmEtYTEwYS01NGFjNzEyZmJkZTYiLCJ0b2tlbl9pZCI6IjQ1M2YzNzEyLTQ1NzMtNGNlNS1hOTg3LWIxNjQ0OGU1ZmRmMSIsImV4cCI6MTc3MzE0NjQ1OSwiaWF0IjoxNzcyNTQxNjU5LCJ0eXBlIjoicmVmcmVzaCJ9.zu6Oj6n3l-xGgRPZqALfUVqowUq5kSJKAitWb2wlgXg	2026-03-10 12:40:59.090252+00	t	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36 Edg/145.0.0.0	2026-03-03 12:40:59.091143+00	2026-03-03 12:41:25.929596+00
377a7dca-34af-4e8c-9df3-6ffdeac0c7a9	0d7f1aa2-b898-4f2a-a10a-54ac712fbde6	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIwZDdmMWFhMi1iODk4LTRmMmEtYTEwYS01NGFjNzEyZmJkZTYiLCJ0b2tlbl9pZCI6IjA0YzQ2YWQ5LTAwYmQtNDQ2My1iNjg0LWMwMmM0NzQ2OGE3MyIsImV4cCI6MTc3MzE0NjgyMywiaWF0IjoxNzcyNTQyMDIzLCJ0eXBlIjoicmVmcmVzaCJ9.7xyckH24oQv8YzpOpzkuxZxS3c3cVk9u6-dCdEPBScU	2026-03-10 12:47:03.789058+00	t	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36 Edg/145.0.0.0	2026-03-03 12:47:03.789729+00	2026-03-03 12:49:57.690343+00
bef53e8c-0c9f-45d2-b15b-15c32862cac7	0d7f1aa2-b898-4f2a-a10a-54ac712fbde6	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIwZDdmMWFhMi1iODk4LTRmMmEtYTEwYS01NGFjNzEyZmJkZTYiLCJ0b2tlbl9pZCI6ImI5ZWRkYjZiLTUxYWMtNGIwMS1hZGI0LWEwMjE2OTFkM2M3NSIsImV4cCI6MTc3MzE0NzAwNCwiaWF0IjoxNzcyNTQyMjA0LCJ0eXBlIjoicmVmcmVzaCJ9.48iZ8JXsC_ViQzSllMl1f3ZGTYjBNMpu1LBLGDGGbMo	2026-03-10 12:50:04.218324+00	t	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36 Edg/145.0.0.0	2026-03-03 12:50:04.218802+00	2026-03-03 12:50:21.740127+00
4fb15df1-b58e-48d5-9302-3decc1d8984e	0d7f1aa2-b898-4f2a-a10a-54ac712fbde6	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIwZDdmMWFhMi1iODk4LTRmMmEtYTEwYS01NGFjNzEyZmJkZTYiLCJ0b2tlbl9pZCI6IjRkMzhlODVlLTBkNDItNDFkZi1iMmMyLTkwMjZjZmU1ZWQ3ZCIsImV4cCI6MTc3MzE0NzAyNywiaWF0IjoxNzcyNTQyMjI3LCJ0eXBlIjoicmVmcmVzaCJ9.XOrkqTJ_i_n4xPM3ULANgEJ1tCSGZKf1HPCX8ZGRHaQ	2026-03-10 12:50:27.132514+00	t	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36 Edg/145.0.0.0	2026-03-03 12:50:27.132868+00	2026-03-03 12:52:32.350923+00
def41684-bdfb-437c-85d3-8f67bbb75a30	2525de1f-db07-4700-a56d-b2976b6ac8e4	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIyNTI1ZGUxZi1kYjA3LTQ3MDAtYTU2ZC1iMjk3NmI2YWM4ZTQiLCJ0b2tlbl9pZCI6IjFjOWY4NjFkLWZhMTQtNDVhMC04NWY4LTI3NmE3NjRjNDc4OCIsImV4cCI6MTc3MzE0NzIzMywiaWF0IjoxNzcyNTQyNDMzLCJ0eXBlIjoicmVmcmVzaCJ9.z2c28Km3b49agmEKE9ybERll7sh4_9vlRpq5xarkAgo	2026-03-10 12:53:53.585508+00	t	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36 Edg/145.0.0.0	2026-03-03 12:53:53.585894+00	2026-03-03 12:55:22.035188+00
cbec45bf-01e2-45aa-98c7-32ba90a94cee	2525de1f-db07-4700-a56d-b2976b6ac8e4	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIyNTI1ZGUxZi1kYjA3LTQ3MDAtYTU2ZC1iMjk3NmI2YWM4ZTQiLCJ0b2tlbl9pZCI6ImNjYzhkYjE2LTI4YWYtNDBiZS04NjVmLWJiZjc2ODVjZjRkOCIsImV4cCI6MTc3MzE0NzMzNSwiaWF0IjoxNzcyNTQyNTM1LCJ0eXBlIjoicmVmcmVzaCJ9.dlPRH_1WOCdBQp1UnhLHGfpUSTJ8-qzWIX1tw2vtuHU	2026-03-10 12:55:35.376689+00	t	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36 Edg/145.0.0.0	2026-03-03 12:55:35.377091+00	2026-03-03 12:55:52.182083+00
66fac682-a4bd-4df7-9691-26e9a541e4e8	0d7f1aa2-b898-4f2a-a10a-54ac712fbde6	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIwZDdmMWFhMi1iODk4LTRmMmEtYTEwYS01NGFjNzEyZmJkZTYiLCJ0b2tlbl9pZCI6ImQwZDEwYTA4LTEzODUtNGE0Ny1hMjg4LWY2ODQ2ZDNhMmUxZSIsImV4cCI6MTc3MzE0NzM1OSwiaWF0IjoxNzcyNTQyNTU5LCJ0eXBlIjoicmVmcmVzaCJ9.vsPBFIDqF0xJzpJhfjumlukVOlJtt_sNjY0X3zrOl54	2026-03-10 12:55:59.659875+00	t	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36 Edg/145.0.0.0	2026-03-03 12:55:59.660353+00	2026-03-03 12:56:06.291998+00
8dcd5fda-53e7-4f5a-ae96-65f76db80dab	0d7f1aa2-b898-4f2a-a10a-54ac712fbde6	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIwZDdmMWFhMi1iODk4LTRmMmEtYTEwYS01NGFjNzEyZmJkZTYiLCJ0b2tlbl9pZCI6IjY3MTEzNmYwLTY3NjUtNDQ3OS1iNjQ3LWYyZmVkNDRjZjA0OSIsImV4cCI6MTc3MzE0NzM5OSwiaWF0IjoxNzcyNTQyNTk5LCJ0eXBlIjoicmVmcmVzaCJ9.1X5VUXC_jOlgBc6_PLoQCypvEoczpGrIF9QChtBIEdc	2026-03-10 12:56:39.272223+00	f	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36 Edg/145.0.0.0	2026-03-03 12:56:39.272668+00	2026-03-03 12:56:39.27267+00
\.


--
-- Data for Name: role_permissions; Type: TABLE DATA; Schema: public; Owner: llmexcel
--

COPY public.role_permissions (id, role_id, permission_id, created_at) FROM stdin;
f4cfed6b-9a90-4363-85a4-1a989a3777b3	a5eb57b2-8e32-41d5-836b-7282b05df40d	3840ce3a-6d84-4be2-a6c5-ba1ecf074d93	2026-02-06 18:20:44.376854+00
a4a713af-2e8d-44e5-93ab-5c6c9761dcbe	2751c212-c193-4225-82b1-6fc0cc850f05	7a1c6e40-100d-452c-b050-43130ee10a5f	2026-02-06 18:20:44.376864+00
b1cf3793-b0c5-4a4b-b905-01a3224f8eda	2751c212-c193-4225-82b1-6fc0cc850f05	aee1f86d-9b2b-43e4-bb35-570f110a9c9c	2026-02-06 18:20:44.376869+00
1a996c3a-478b-4881-a14b-cf1bb29e9d5a	2751c212-c193-4225-82b1-6fc0cc850f05	2beb5acc-9811-4cc5-bfe3-878f372a92c5	2026-02-06 18:20:44.376873+00
edbdcce4-6d30-4515-8828-d79f4baf6ff0	2751c212-c193-4225-82b1-6fc0cc850f05	a6c0508e-354b-488c-87ad-4bb3ea5fe300	2026-02-06 18:20:44.376878+00
9d32b878-6321-46a3-be07-8c665c79bd17	2751c212-c193-4225-82b1-6fc0cc850f05	83613907-85cf-46d6-905c-2b6bd023634e	2026-02-06 18:20:44.376882+00
37b543c2-e7db-4f3f-bcec-f23419926ed9	2751c212-c193-4225-82b1-6fc0cc850f05	261721b6-025e-491f-8f2e-94db155d5979	2026-02-06 18:20:44.376887+00
3a2818f5-5519-4c56-bcc4-b754f8ba9e20	2751c212-c193-4225-82b1-6fc0cc850f05	9017e12a-1691-468c-b721-330bbc911949	2026-02-06 18:20:44.376891+00
43fcee28-f778-4b00-abcb-c6d2448ce373	2751c212-c193-4225-82b1-6fc0cc850f05	c5a89bbd-78bb-43ef-836f-e5d4ba761328	2026-02-06 18:20:44.376896+00
62c5cc0c-db58-49fd-b75e-86a105baf88c	2751c212-c193-4225-82b1-6fc0cc850f05	ace2e589-2744-4451-ac7e-7582e4c367bd	2026-02-06 18:20:44.3769+00
b764413f-4de8-4cfa-ac21-12cd0ab7eb5d	2751c212-c193-4225-82b1-6fc0cc850f05	88a6cb6a-f2aa-42ac-b4a8-60f0042bbd48	2026-02-06 18:20:44.376904+00
f1c64524-595b-43bf-bb7a-885a469db65a	2751c212-c193-4225-82b1-6fc0cc850f05	11bb4613-0754-43f9-b70c-74915b88a3f9	2026-02-06 18:20:44.376909+00
838d0d92-9e32-4c14-93c5-542ed196c0c5	2751c212-c193-4225-82b1-6fc0cc850f05	6f4c185f-f02f-4fc6-bea9-2696cf81d32c	2026-02-06 18:20:44.376913+00
80e8072c-7762-470e-baad-db6d5fc281a1	dc91ea35-de5b-4520-80a1-21fa69721b4a	7a1c6e40-100d-452c-b050-43130ee10a5f	2026-02-06 18:20:44.376917+00
cf4e6c1d-206a-481d-b553-f79f6cda6b2b	dc91ea35-de5b-4520-80a1-21fa69721b4a	88a6cb6a-f2aa-42ac-b4a8-60f0042bbd48	2026-02-06 18:20:44.376922+00
919af728-a1f4-4c3b-952a-1d0bbcb5da8d	4c88b1ce-a02c-4626-83d1-37da793fa568	7a1c6e40-100d-452c-b050-43130ee10a5f	2026-02-06 18:20:44.376926+00
37e32f57-cbbc-48d3-92bc-ba7e1dffcc14	4c88b1ce-a02c-4626-83d1-37da793fa568	1390160c-820b-4166-824b-9e68de14ff99	2026-02-06 18:20:44.37693+00
8fbbee0c-4d9f-4b1c-bff8-a22ec34219bc	4c88b1ce-a02c-4626-83d1-37da793fa568	aee1f86d-9b2b-43e4-bb35-570f110a9c9c	2026-02-06 18:20:44.376935+00
6d77f105-d834-4a9a-81ec-c5bafa6a152c	4c88b1ce-a02c-4626-83d1-37da793fa568	2beb5acc-9811-4cc5-bfe3-878f372a92c5	2026-02-06 18:20:44.376939+00
0e1d5d14-bb70-4978-95e5-eb51b5ba1d06	4c88b1ce-a02c-4626-83d1-37da793fa568	83613907-85cf-46d6-905c-2b6bd023634e	2026-02-06 18:20:44.376944+00
c8191167-8202-4e50-a16c-8851a596877e	4c88b1ce-a02c-4626-83d1-37da793fa568	261721b6-025e-491f-8f2e-94db155d5979	2026-02-06 18:20:44.376948+00
ad8b1780-7d84-4153-8518-fc4fdf4567a1	4c88b1ce-a02c-4626-83d1-37da793fa568	10eb8e34-e6de-4e51-8708-d9e3092b1c33	2026-02-06 18:20:44.376952+00
ffb892e4-0f6b-4c6e-bc57-434b575cae3d	4c88b1ce-a02c-4626-83d1-37da793fa568	c5a89bbd-78bb-43ef-836f-e5d4ba761328	2026-02-06 18:20:44.376957+00
436cbdd7-9227-4759-a9a6-a230be72bd97	4c88b1ce-a02c-4626-83d1-37da793fa568	ace2e589-2744-4451-ac7e-7582e4c367bd	2026-02-06 18:20:44.376961+00
e6a8b0e7-9ba4-4487-8e67-16e963445498	4c88b1ce-a02c-4626-83d1-37da793fa568	88a6cb6a-f2aa-42ac-b4a8-60f0042bbd48	2026-02-06 18:20:44.376966+00
da496f3f-45ea-445e-a114-62091ed81f8e	4c88b1ce-a02c-4626-83d1-37da793fa568	11bb4613-0754-43f9-b70c-74915b88a3f9	2026-02-06 18:20:44.37697+00
c3d67716-70de-45c6-9ae3-d385305c9d28	4c88b1ce-a02c-4626-83d1-37da793fa568	6f4c185f-f02f-4fc6-bea9-2696cf81d32c	2026-02-06 18:20:44.376974+00
029f9a6a-b7d4-4c13-8277-9e1f1b3a1ebf	4c88b1ce-a02c-4626-83d1-37da793fa568	3dc6d70a-00f0-424c-a6f2-59679d9311fd	2026-02-06 18:20:44.376979+00
f4ab4582-9165-486e-99ce-f2231094845e	4c88b1ce-a02c-4626-83d1-37da793fa568	eb4a52d4-c4bd-4ca7-9519-d219f0d242c9	2026-02-06 18:20:44.376983+00
0105966e-6567-492b-a94d-3ea0a9b7a8ba	4c88b1ce-a02c-4626-83d1-37da793fa568	6ce4b23c-3aa7-4b04-86a6-12b26654887f	2026-02-06 18:20:44.376987+00
fb9d1f80-7845-49d4-981c-00286fafb504	4c88b1ce-a02c-4626-83d1-37da793fa568	84a4a2d5-abf4-439e-8844-042f463b752e	2026-02-06 18:20:44.376992+00
\.


--
-- Data for Name: roles; Type: TABLE DATA; Schema: public; Owner: llmexcel
--

COPY public.roles (id, name, code, description, is_system, created_at, updated_at) FROM stdin;
a5eb57b2-8e32-41d5-836b-7282b05df40d	系统管理员	admin	拥有所有权限，可管理用户、角色、权限	t	2026-02-06 18:20:44.297621+00	2026-02-06 18:20:44.297629+00
2751c212-c193-4225-82b1-6fc0cc850f05	普通用户	user	基础用户权限，可使用核心功能	t	2026-02-06 18:20:44.3116+00	2026-02-06 18:20:44.311606+00
dc91ea35-de5b-4520-80a1-21fa69721b4a	访客	guest	只读权限，用于演示或试用	t	2026-02-06 18:20:44.315946+00	2026-02-06 18:20:44.315949+00
4c88b1ce-a02c-4626-83d1-37da793fa568	运营人员	operator	可查看所有数据，管理异常记录	t	2026-02-06 18:20:44.318188+00	2026-02-06 18:20:44.318192+00
\.


--
-- Data for Name: thread_turns; Type: TABLE DATA; Schema: public; Owner: llmexcel
--

COPY public.thread_turns (id, thread_id, turn_number, user_query, status, steps, created_at, started_at, completed_at, updated_at) FROM stdin;
907b727b-1063-4b1d-9af2-b0d7162cbb5c	1fd4ffb1-c5ed-4fa8-992e-5b6b1d5f5547	1	删除年龄列	completed	[{"step": "load", "output": {"files": [{"sheets": [{"name": "train", "columns": [{"name": "PassengerId", "type": "number", "letter": "A"}, {"name": "Survived", "type": "number", "letter": "B"}, {"name": "Pclass", "type": "number", "letter": "C"}, {"name": "Name", "type": "text", "letter": "D"}, {"name": "Sex", "type": "text", "letter": "E"}, {"name": "Age", "type": "number", "letter": "F"}, {"name": "SibSp", "type": "number", "letter": "G"}, {"name": "Parch", "type": "number", "letter": "H"}, {"name": "Ticket", "type": "text", "letter": "I"}, {"name": "Fare", "type": "number", "letter": "J"}, {"name": "Cabin", "type": "text", "letter": "K"}, {"name": "Embarked", "type": "text", "letter": "L"}], "row_count": 891}], "file_id": "1_titanic", "filename": "1_titanic.xlsx"}]}, "status": "done", "started_at": "2026-03-03T12:41:12.055439+00:00", "completed_at": "2026-03-03T12:41:12.384478+00:00"}, {"step": "generate", "output": {"operations": [{"type": "drop_columns", "table": "train", "output": {"type": "in_place"}, "columns": ["Age"], "file_id": "1_titanic", "description": "删除年龄列"}]}, "status": "done", "started_at": "2026-03-03T12:41:12.395011+00:00", "completed_at": "2026-03-03T12:41:16.202806+00:00"}, {"step": "validate", "output": {"valid": true, "errors": null, "operation_count": 1}, "status": "done", "started_at": "2026-03-03T12:41:16.205322+00:00", "completed_at": "2026-03-03T12:41:16.205813+00:00"}, {"step": "execute", "output": {"errors": null, "strategy": "📋 处理思路\\n\\n本次处理共 1 步：\\n\\n步骤 1：删除年龄列\\n├─ 操作：删除列\\n├─ 目标：1_titanic.xlsx / train\\n├─ 删除列：Age\\n└─ 方法：CHOOSECOLS 函数\\n\\n→ 最终结果：处理完成", "manual_steps": "🔧 手动操作步骤\\n\\n步骤 1：删除年龄列\\n   1. 打开 1_titanic.xlsx，切换到「train」工作表\\n   2. 按住 Ctrl（或 Cmd）依次点击列标题，选中要删除的列：「Age」\\n   3. 右键 →「删除」\\n\\n---\\n💡 Excel 365 用户提示\\n如果你使用 Excel 365，可以用以下公式替代部分操作：\\n\\n步骤 1（删除年龄列）：\\n   =CHOOSECOLS(train!A:Z, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11)\\n"}, "status": "done", "started_at": "2026-03-03T12:41:16.208290+00:00", "completed_at": "2026-03-03T12:41:16.219973+00:00"}, {"step": "export", "output": {"output_files": [{"url": "/storage/llm-excel/users/0d7f1aa2-b898-4f2a-a10a-54ac712fbde6/outputs/20260303_124116/1_titanic.xlsx", "file_id": "1_titanic", "filename": "1_titanic.xlsx"}]}, "status": "done", "started_at": "2026-03-03T12:41:16.222800+00:00", "completed_at": "2026-03-03T12:41:16.468348+00:00"}]	2026-03-03 12:41:12.018281+00	2026-03-03 12:41:12.052904+00	2026-03-03 12:41:16.470665+00	2026-03-03 12:41:16.474058+00
\.


--
-- Data for Name: threads; Type: TABLE DATA; Schema: public; Owner: llmexcel
--

COPY public.threads (id, user_id, title, status, created_at, updated_at) FROM stdin;
1fd4ffb1-c5ed-4fa8-992e-5b6b1d5f5547	0d7f1aa2-b898-4f2a-a10a-54ac712fbde6	删除年龄列	active	2026-03-03 12:41:11.994863+00	2026-03-03 12:41:16.470665+00
\.


--
-- Data for Name: turn_files; Type: TABLE DATA; Schema: public; Owner: llmexcel
--

COPY public.turn_files (id, turn_id, file_id, created_at) FROM stdin;
f0a1704a-c31f-4278-b492-605216bfbc0b	907b727b-1063-4b1d-9af2-b0d7162cbb5c	7011c47e-2266-482f-b146-c2c8faeb1e1a	2026-03-03 12:41:12.034813+00
\.


--
-- Data for Name: user_roles; Type: TABLE DATA; Schema: public; Owner: llmexcel
--

COPY public.user_roles (id, user_id, role_id, created_at) FROM stdin;
88671c44-bfc7-4abc-8176-904bb3745c98	d7fe11df-0914-440f-a7fd-ff61aa05ab9d	a5eb57b2-8e32-41d5-836b-7282b05df40d	2026-02-07 12:17:08+00
cc2d006d-28e6-4229-add3-3b7de0555494	0d7f1aa2-b898-4f2a-a10a-54ac712fbde6	2751c212-c193-4225-82b1-6fc0cc850f05	2026-03-03 12:40:53.981334+00
c4d39e37-a31c-47d3-a218-ff40cfd684be	0d7f1aa2-b898-4f2a-a10a-54ac712fbde6	a5eb57b2-8e32-41d5-836b-7282b05df40d	2026-03-03 12:49:51.113602+00
378513ce-1c6b-460f-9160-7ef6d0a8702e	43cb8f36-2330-49e8-bdab-febc0338268e	2751c212-c193-4225-82b1-6fc0cc850f05	2026-03-03 12:53:00.317634+00
3d8068a7-931e-45a5-bd06-d33934bf98ad	2525de1f-db07-4700-a56d-b2976b6ac8e4	2751c212-c193-4225-82b1-6fc0cc850f05	2026-03-03 12:53:37.815342+00
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: llmexcel
--

COPY public.users (id, username, avatar, status, created_at, updated_at, last_login_at) FROM stdin;
d7fe11df-0914-440f-a7fd-ff61aa05ab9d	admin	/storage/llm-excel/__SYS__/admin_avatar.svg	0	2026-02-07 04:15:20.735399+00	2026-02-07 05:00:11.662599+00	2026-02-07 04:15:41.648558+00
43cb8f36-2330-49e8-bdab-febc0338268e	1234	/storage/llm-excel/__SYS__/default_avatar.png	0	2026-03-03 12:53:00.091569+00	2026-03-03 12:53:00.091572+00	\N
2525de1f-db07-4700-a56d-b2976b6ac8e4	test	/storage/llm-excel/__SYS__/default_avatar.png	0	2026-03-03 12:53:37.589299+00	2026-03-03 12:55:35.37845+00	2026-03-03 12:55:35.378251+00
0d7f1aa2-b898-4f2a-a10a-54ac712fbde6	1111	/storage/llm-excel/__SYS__/default_avatar.png	0	2026-03-03 12:40:53.753245+00	2026-03-03 12:56:39.2749+00	2026-03-03 12:56:39.274613+00
\.


--
-- Name: accounts accounts_pkey; Type: CONSTRAINT; Schema: public; Owner: llmexcel
--

ALTER TABLE ONLY public.accounts
    ADD CONSTRAINT accounts_pkey PRIMARY KEY (id);


--
-- Name: alembic_version alembic_version_pkc; Type: CONSTRAINT; Schema: public; Owner: llmexcel
--

ALTER TABLE ONLY public.alembic_version
    ADD CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num);


--
-- Name: btracks btracks_pkey; Type: CONSTRAINT; Schema: public; Owner: llmexcel
--

ALTER TABLE ONLY public.btracks
    ADD CONSTRAINT btracks_pkey PRIMARY KEY (id);


--
-- Name: files files_pkey; Type: CONSTRAINT; Schema: public; Owner: llmexcel
--

ALTER TABLE ONLY public.files
    ADD CONSTRAINT files_pkey PRIMARY KEY (id);


--
-- Name: permissions permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: llmexcel
--

ALTER TABLE ONLY public.permissions
    ADD CONSTRAINT permissions_pkey PRIMARY KEY (id);


--
-- Name: refresh_tokens refresh_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: llmexcel
--

ALTER TABLE ONLY public.refresh_tokens
    ADD CONSTRAINT refresh_tokens_pkey PRIMARY KEY (id);


--
-- Name: role_permissions role_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: llmexcel
--

ALTER TABLE ONLY public.role_permissions
    ADD CONSTRAINT role_permissions_pkey PRIMARY KEY (id);


--
-- Name: roles roles_pkey; Type: CONSTRAINT; Schema: public; Owner: llmexcel
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_pkey PRIMARY KEY (id);


--
-- Name: thread_turns thread_turns_pkey; Type: CONSTRAINT; Schema: public; Owner: llmexcel
--

ALTER TABLE ONLY public.thread_turns
    ADD CONSTRAINT thread_turns_pkey PRIMARY KEY (id);


--
-- Name: threads threads_pkey; Type: CONSTRAINT; Schema: public; Owner: llmexcel
--

ALTER TABLE ONLY public.threads
    ADD CONSTRAINT threads_pkey PRIMARY KEY (id);


--
-- Name: turn_files turn_files_pkey; Type: CONSTRAINT; Schema: public; Owner: llmexcel
--

ALTER TABLE ONLY public.turn_files
    ADD CONSTRAINT turn_files_pkey PRIMARY KEY (id);


--
-- Name: accounts uq_account_provider_account; Type: CONSTRAINT; Schema: public; Owner: llmexcel
--

ALTER TABLE ONLY public.accounts
    ADD CONSTRAINT uq_account_provider_account UNIQUE (provider_id, account_id);


--
-- Name: role_permissions uq_role_permission; Type: CONSTRAINT; Schema: public; Owner: llmexcel
--

ALTER TABLE ONLY public.role_permissions
    ADD CONSTRAINT uq_role_permission UNIQUE (role_id, permission_id);


--
-- Name: thread_turns uq_thread_turn; Type: CONSTRAINT; Schema: public; Owner: llmexcel
--

ALTER TABLE ONLY public.thread_turns
    ADD CONSTRAINT uq_thread_turn UNIQUE (thread_id, turn_number);


--
-- Name: turn_files uq_turn_file; Type: CONSTRAINT; Schema: public; Owner: llmexcel
--

ALTER TABLE ONLY public.turn_files
    ADD CONSTRAINT uq_turn_file UNIQUE (turn_id, file_id);


--
-- Name: user_roles uq_user_role; Type: CONSTRAINT; Schema: public; Owner: llmexcel
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT uq_user_role UNIQUE (user_id, role_id);


--
-- Name: user_roles user_roles_pkey; Type: CONSTRAINT; Schema: public; Owner: llmexcel
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: llmexcel
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: ix_accounts_id; Type: INDEX; Schema: public; Owner: llmexcel
--

CREATE INDEX ix_accounts_id ON public.accounts USING btree (id);


--
-- Name: ix_accounts_provider_id; Type: INDEX; Schema: public; Owner: llmexcel
--

CREATE INDEX ix_accounts_provider_id ON public.accounts USING btree (provider_id);


--
-- Name: ix_accounts_user_id; Type: INDEX; Schema: public; Owner: llmexcel
--

CREATE INDEX ix_accounts_user_id ON public.accounts USING btree (user_id);


--
-- Name: ix_btracks_id; Type: INDEX; Schema: public; Owner: llmexcel
--

CREATE INDEX ix_btracks_id ON public.btracks USING btree (id);


--
-- Name: ix_btracks_reporter_id; Type: INDEX; Schema: public; Owner: llmexcel
--

CREATE INDEX ix_btracks_reporter_id ON public.btracks USING btree (reporter_id);


--
-- Name: ix_files_id; Type: INDEX; Schema: public; Owner: llmexcel
--

CREATE INDEX ix_files_id ON public.files USING btree (id);


--
-- Name: ix_files_md5; Type: INDEX; Schema: public; Owner: llmexcel
--

CREATE INDEX ix_files_md5 ON public.files USING btree (md5);


--
-- Name: ix_files_uploaded_at; Type: INDEX; Schema: public; Owner: llmexcel
--

CREATE INDEX ix_files_uploaded_at ON public.files USING btree (uploaded_at);


--
-- Name: ix_files_user_id; Type: INDEX; Schema: public; Owner: llmexcel
--

CREATE INDEX ix_files_user_id ON public.files USING btree (user_id);


--
-- Name: ix_permissions_code; Type: INDEX; Schema: public; Owner: llmexcel
--

CREATE UNIQUE INDEX ix_permissions_code ON public.permissions USING btree (code);


--
-- Name: ix_permissions_id; Type: INDEX; Schema: public; Owner: llmexcel
--

CREATE INDEX ix_permissions_id ON public.permissions USING btree (id);


--
-- Name: ix_refresh_tokens_expires_at; Type: INDEX; Schema: public; Owner: llmexcel
--

CREATE INDEX ix_refresh_tokens_expires_at ON public.refresh_tokens USING btree (expires_at);


--
-- Name: ix_refresh_tokens_id; Type: INDEX; Schema: public; Owner: llmexcel
--

CREATE INDEX ix_refresh_tokens_id ON public.refresh_tokens USING btree (id);


--
-- Name: ix_refresh_tokens_token; Type: INDEX; Schema: public; Owner: llmexcel
--

CREATE UNIQUE INDEX ix_refresh_tokens_token ON public.refresh_tokens USING btree (token);


--
-- Name: ix_refresh_tokens_user_id; Type: INDEX; Schema: public; Owner: llmexcel
--

CREATE INDEX ix_refresh_tokens_user_id ON public.refresh_tokens USING btree (user_id);


--
-- Name: ix_role_permissions_permission_id; Type: INDEX; Schema: public; Owner: llmexcel
--

CREATE INDEX ix_role_permissions_permission_id ON public.role_permissions USING btree (permission_id);


--
-- Name: ix_role_permissions_role_id; Type: INDEX; Schema: public; Owner: llmexcel
--

CREATE INDEX ix_role_permissions_role_id ON public.role_permissions USING btree (role_id);


--
-- Name: ix_roles_code; Type: INDEX; Schema: public; Owner: llmexcel
--

CREATE UNIQUE INDEX ix_roles_code ON public.roles USING btree (code);


--
-- Name: ix_roles_id; Type: INDEX; Schema: public; Owner: llmexcel
--

CREATE INDEX ix_roles_id ON public.roles USING btree (id);


--
-- Name: ix_roles_is_system; Type: INDEX; Schema: public; Owner: llmexcel
--

CREATE INDEX ix_roles_is_system ON public.roles USING btree (is_system);


--
-- Name: ix_roles_name; Type: INDEX; Schema: public; Owner: llmexcel
--

CREATE UNIQUE INDEX ix_roles_name ON public.roles USING btree (name);


--
-- Name: ix_thread_turns_created_at; Type: INDEX; Schema: public; Owner: llmexcel
--

CREATE INDEX ix_thread_turns_created_at ON public.thread_turns USING btree (created_at);


--
-- Name: ix_thread_turns_id; Type: INDEX; Schema: public; Owner: llmexcel
--

CREATE INDEX ix_thread_turns_id ON public.thread_turns USING btree (id);


--
-- Name: ix_thread_turns_status; Type: INDEX; Schema: public; Owner: llmexcel
--

CREATE INDEX ix_thread_turns_status ON public.thread_turns USING btree (status);


--
-- Name: ix_thread_turns_thread_id; Type: INDEX; Schema: public; Owner: llmexcel
--

CREATE INDEX ix_thread_turns_thread_id ON public.thread_turns USING btree (thread_id);


--
-- Name: ix_threads_id; Type: INDEX; Schema: public; Owner: llmexcel
--

CREATE INDEX ix_threads_id ON public.threads USING btree (id);


--
-- Name: ix_threads_status; Type: INDEX; Schema: public; Owner: llmexcel
--

CREATE INDEX ix_threads_status ON public.threads USING btree (status);


--
-- Name: ix_threads_updated_at; Type: INDEX; Schema: public; Owner: llmexcel
--

CREATE INDEX ix_threads_updated_at ON public.threads USING btree (updated_at);


--
-- Name: ix_threads_user_id; Type: INDEX; Schema: public; Owner: llmexcel
--

CREATE INDEX ix_threads_user_id ON public.threads USING btree (user_id);


--
-- Name: ix_turn_files_file_id; Type: INDEX; Schema: public; Owner: llmexcel
--

CREATE INDEX ix_turn_files_file_id ON public.turn_files USING btree (file_id);


--
-- Name: ix_turn_files_turn_id; Type: INDEX; Schema: public; Owner: llmexcel
--

CREATE INDEX ix_turn_files_turn_id ON public.turn_files USING btree (turn_id);


--
-- Name: ix_user_roles_role_id; Type: INDEX; Schema: public; Owner: llmexcel
--

CREATE INDEX ix_user_roles_role_id ON public.user_roles USING btree (role_id);


--
-- Name: ix_user_roles_user_id; Type: INDEX; Schema: public; Owner: llmexcel
--

CREATE INDEX ix_user_roles_user_id ON public.user_roles USING btree (user_id);


--
-- Name: ix_users_id; Type: INDEX; Schema: public; Owner: llmexcel
--

CREATE INDEX ix_users_id ON public.users USING btree (id);


--
-- Name: ix_users_status; Type: INDEX; Schema: public; Owner: llmexcel
--

CREATE INDEX ix_users_status ON public.users USING btree (status);


--
-- Name: ix_users_username; Type: INDEX; Schema: public; Owner: llmexcel
--

CREATE UNIQUE INDEX ix_users_username ON public.users USING btree (username);


--
-- Name: accounts accounts_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: llmexcel
--

ALTER TABLE ONLY public.accounts
    ADD CONSTRAINT accounts_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: files files_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: llmexcel
--

ALTER TABLE ONLY public.files
    ADD CONSTRAINT files_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: refresh_tokens refresh_tokens_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: llmexcel
--

ALTER TABLE ONLY public.refresh_tokens
    ADD CONSTRAINT refresh_tokens_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: role_permissions role_permissions_permission_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: llmexcel
--

ALTER TABLE ONLY public.role_permissions
    ADD CONSTRAINT role_permissions_permission_id_fkey FOREIGN KEY (permission_id) REFERENCES public.permissions(id) ON DELETE CASCADE;


--
-- Name: role_permissions role_permissions_role_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: llmexcel
--

ALTER TABLE ONLY public.role_permissions
    ADD CONSTRAINT role_permissions_role_id_fkey FOREIGN KEY (role_id) REFERENCES public.roles(id) ON DELETE CASCADE;


--
-- Name: thread_turns thread_turns_thread_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: llmexcel
--

ALTER TABLE ONLY public.thread_turns
    ADD CONSTRAINT thread_turns_thread_id_fkey FOREIGN KEY (thread_id) REFERENCES public.threads(id) ON DELETE CASCADE;


--
-- Name: threads threads_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: llmexcel
--

ALTER TABLE ONLY public.threads
    ADD CONSTRAINT threads_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: turn_files turn_files_file_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: llmexcel
--

ALTER TABLE ONLY public.turn_files
    ADD CONSTRAINT turn_files_file_id_fkey FOREIGN KEY (file_id) REFERENCES public.files(id) ON DELETE CASCADE;


--
-- Name: turn_files turn_files_turn_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: llmexcel
--

ALTER TABLE ONLY public.turn_files
    ADD CONSTRAINT turn_files_turn_id_fkey FOREIGN KEY (turn_id) REFERENCES public.thread_turns(id) ON DELETE CASCADE;


--
-- Name: user_roles user_roles_role_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: llmexcel
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_role_id_fkey FOREIGN KEY (role_id) REFERENCES public.roles(id) ON DELETE CASCADE;


--
-- Name: user_roles user_roles_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: llmexcel
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict 2kTlexZJM7U3KEwrDy3BH1XCCvh9xsxhdJj9GcPOoE5gS2ZYPraH0pTwrUSTPF1

